#ifndef __LED_H
#define __led_H

void LED_Init(void);
void LED1_ON(void );
void LED1_OFF(void );
void LED2_ON(void );
void LED2_OFF(void );
void LED1_turn(void);
void LED2_turn(void);

#endif
