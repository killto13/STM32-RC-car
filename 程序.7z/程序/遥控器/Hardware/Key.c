#include "stm32f10x.h"                  // Device header
#include "delay.h" //delay(时间）函数头文件
void Key_Init(void)
{
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOB,ENABLE );
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //读取按键，上拉输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}

uint8_t Key_GgetNum(void) //读取按键值
{
	uint8_t KeyNum = 0; //按键键码默认给0，若没有按键按下，就返回0。 KeyNum：局部变量
	//按键按下
	if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10) ==0)//GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10) 读取PB10端口值
	{
		Delay_ms(20); //消除按键按下抖动
		//		while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10) ==0); //满足条件，程序循环（卡在这里），不符合条件，程序中断（跳转到下一个程序）加上为检测下降沿，不加上为点动
		Delay_ms(20); //消除按键松手抖动
		KeyNum = 1;
	}
	
	
	if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) ==0)//GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) 读取PB11端口值
	{
		Delay_ms(20); //消除按键按下抖动
//		while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) ==0); //满足条件，程序循环（卡在这里），不符合条件，程序中断（跳转到下一个程序）
		Delay_ms(20); //消除按键松手抖动
		KeyNum = 2;
	}
	
		if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0) ==0)//GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10) 读取PB10端口值
	{
		Delay_ms(20); //消除按键按下抖动
		//		while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10) ==0); //满足条件，程序循环（卡在这里），不符合条件，程序中断（跳转到下一个程序）加上为检测下降沿，不加上为点动
		Delay_ms(20); //消除按键松手抖动
		KeyNum = 3;
	}
	
	
	if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1) ==0)//GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) 读取PB11端口值
	{
		Delay_ms(20); //消除按键按下抖动
//		while (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11) ==0); //满足条件，程序循环（卡在这里），不符合条件，程序中断（跳转到下一个程序）
		Delay_ms(20); //消除按键松手抖动
		KeyNum = 4;
	}
	

	return KeyNum; //返回值
}
	
uint8_t Key_GgetNum2(void) //读取按键值方向
{

	uint8_t Direction = 0;
		if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) ==0)
	{
		Delay_ms(20); //消除按键按下抖动
		Delay_ms(20); //消除按键松手抖动
		Direction = 1;
	}
	
	if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) ==0)
	{
		Delay_ms(20); //消除按键按下抖动
		Delay_ms(20); //消除按键松手抖动
		Direction = 2;
	}
	

	
	return Direction; //返回值
}
	
