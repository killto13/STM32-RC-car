#ifndef __LED_H
#define __led_H

void Gpio_Init(void);

#endif
