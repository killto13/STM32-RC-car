#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Motor1_Init(void)
{
	//��ʼ��GPIO
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOB ,ENABLE );
	GPIO_InitTypeDef GPIO_Initstructure;
	GPIO_Initstructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_Initstructure.GPIO_Pin =  GPIO_Pin_10 |GPIO_Pin_11;
	GPIO_Initstructure.GPIO_Speed = GPIO_Speed_50MHz ;
	GPIO_Init (GPIOB,&GPIO_Initstructure);
	

	
	PWM1_Init(); //��ʼ��PWM1

	
}
void Motor2_Init(void)
{
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOA ,ENABLE );
	GPIO_InitTypeDef GPIO_Initstructure;
	GPIO_Initstructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_Initstructure.GPIO_Pin = GPIO_Pin_8 |GPIO_Pin_9 |GPIO_Pin_10 |GPIO_Pin_11 |GPIO_Pin_3 |GPIO_Pin_4;
	GPIO_Initstructure.GPIO_Speed = GPIO_Speed_50MHz ;
	GPIO_Init (GPIOA,&GPIO_Initstructure);

	PWM2_Init(); //��ʼ��PWM2
}


//���õ���ٶ�
void R_A_Motor_SetSpeed1(int8_t Speed) //���1 ���ϣ�STLINKΪ�ϣ�
{
	//��ת��>0Ϊ��ת
	if (Speed >= 0 )
	{
		//A3��ת����A3���ر�A4
		GPIO_SetBits (GPIOA,GPIO_Pin_3);
		GPIO_ResetBits (GPIOA,GPIO_Pin_4);
		//�ٶ�
		PWM_SetCompare1(Speed);
		
	}
	//SpeedΪ������������ת
	else
	{
		//A4��ת����A4���ر�A3
		GPIO_ResetBits (GPIOA,GPIO_Pin_3);
		GPIO_SetBits (GPIOA,GPIO_Pin_4);
		//�ٶ�
		PWM_SetCompare1(-Speed);
		
		
	}		
}

void L_A_Motor_SetSpeed2(int8_t Speed) //���2 ���ϣ�STLINKΪ�ϣ�
{
	if (Speed >= 0 )
	{
		GPIO_SetBits (GPIOA,GPIO_Pin_8);
		GPIO_ResetBits (GPIOA,GPIO_Pin_9);
		PWM_SetCompare2(Speed);
		
	}
	else
	{
		GPIO_ResetBits (GPIOA,GPIO_Pin_8);
		GPIO_SetBits (GPIOA,GPIO_Pin_9);
		PWM_SetCompare2(-Speed);
		
		
	}		
}
void L_B_Motor_SetSpeed3(int8_t Speed) //���3 ���£�STLINKΪ�ϣ�
{
	if (Speed >= 0 )
	{
		GPIO_SetBits (GPIOA,GPIO_Pin_10);
		GPIO_ResetBits (GPIOA,GPIO_Pin_11);
		PWM_SetCompare3(Speed);
		
	}
	else
	{
		GPIO_ResetBits (GPIOA,GPIO_Pin_10);
		GPIO_SetBits (GPIOA,GPIO_Pin_11);
		PWM_SetCompare3(-Speed);
		
		
	}		
}

void R_B_Motor_SetSpeed4(int8_t Speed) //���4 ���£�STLINKΪ�ϣ�
{
	if (Speed >= 0 )
	{
		GPIO_SetBits (GPIOB,GPIO_Pin_10);
		GPIO_ResetBits (GPIOB,GPIO_Pin_11);
		PWM_SetCompare4(Speed);
		
	}
	else
	{
		GPIO_ResetBits (GPIOB,GPIO_Pin_10);
		GPIO_SetBits (GPIOB,GPIO_Pin_11);
		PWM_SetCompare4(-Speed);
		
		
	}
}



void Motor_RESET (void)
{
	GPIO_ResetBits (GPIOA,GPIO_Pin_3);
	GPIO_ResetBits (GPIOA,GPIO_Pin_4);
	GPIO_ResetBits (GPIOA,GPIO_Pin_8);
	GPIO_ResetBits (GPIOA,GPIO_Pin_9);
	GPIO_ResetBits (GPIOA,GPIO_Pin_10);
	GPIO_ResetBits (GPIOA,GPIO_Pin_11);
	GPIO_ResetBits (GPIOB,GPIO_Pin_10);
	GPIO_ResetBits (GPIOB,GPIO_Pin_11);

	
}


