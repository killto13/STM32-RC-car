#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "OLED.h"
//#include "AD.h"
#include "NRF24L01.h"
#include "MySPI.h"
#include "Motor.h"
#include "Encoder.h"
#include "LED.h"

int16_t Num;
int16_t SpeedG;


int main (void)
{
	


	OLED_Init();
	//AD_Init(); //��ʼ��ADC
	NRF24L01_Init();
	Motor1_Init();
	Motor2_Init();
	Encoder_Init();
	Gpio_Init();
	
	OLED_ShowString(1,1, "POWER");	
	OLED_ShowString(2,9, "Num:"); 
	
	while(NRF24L01_Check());//�ȴ���⵽NRF24L01������Ż�����ִ��
	OLED_ShowString(1,11, "READY");
	
	


	while (1)
	{	
	NRF24L01_RX_Mode(); //����ģʽ	
	while (NRF24L01_RxPacket(RF2G4_Receive_Data)==RX_OK); //�ܷ��ѭ����/�ܷ���ڷ���ģʽ����
	NRF24L01_RxPacket(RF2G4_Receive_Data);

	//���ռ������ݰ�
	/***************/

	if (RF2G4_Receive_Data[12] == 102|RF2G4_Receive_Data[13] == 111)
	{
		
	OLED_ShowString(2,1,"CONNECT");
		

//	Num += Encoder_Get();
	Num ++;
	if (Num >= 10)
	{
		SpeedG = Speed_Get() * 10;		
		Num = 0;
	}
	OLED_ShowSignedNum (2,12,SpeedG,4);

		
/***************************************************************************************************/
		//���Ӷ�������
		if(RF2G4_Receive_Data[5] == 1) //ǰ��
		{
			if(RF2G4_Receive_Data[7] == 1) //��ת�ж�
			{
				R_A_Motor_SetSpeed1(-RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
				L_A_Motor_SetSpeed2(RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
				L_B_Motor_SetSpeed3(RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
				R_B_Motor_SetSpeed4(-RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
			}
			else if(RF2G4_Receive_Data[8] == 1) //��ת�ж�
			{
				R_A_Motor_SetSpeed1(RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
				L_A_Motor_SetSpeed2(-RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
				L_B_Motor_SetSpeed3(-RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
				R_B_Motor_SetSpeed4(RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
			}
			else if(RF2G4_Receive_Data[3] == 1) //ɲ���ж�
			{
				GPIO_ResetBits (GPIOA,GPIO_Pin_3);
				GPIO_ResetBits (GPIOA,GPIO_Pin_4);
				GPIO_ResetBits (GPIOA,GPIO_Pin_8);
				GPIO_ResetBits (GPIOA,GPIO_Pin_9);
				GPIO_ResetBits (GPIOA,GPIO_Pin_10);
				GPIO_ResetBits (GPIOA,GPIO_Pin_11);
				GPIO_ResetBits (GPIOB,GPIO_Pin_10);
				GPIO_ResetBits (GPIOB,GPIO_Pin_11);
			}
			else //ֱ��
			{
				R_A_Motor_SetSpeed1(RF2G4_Receive_Data[0]);
				L_A_Motor_SetSpeed2(RF2G4_Receive_Data[0]);
				L_B_Motor_SetSpeed3(RF2G4_Receive_Data[0]);
				R_B_Motor_SetSpeed4(RF2G4_Receive_Data[0]);
			}
		}
		
		else if(RF2G4_Receive_Data[6] == 1) //����
		{
			if(RF2G4_Receive_Data[7] == 1) //��ת�ж�
			{
				R_A_Motor_SetSpeed1(-RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
				L_A_Motor_SetSpeed2(RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
				L_B_Motor_SetSpeed3(RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
				R_B_Motor_SetSpeed4(-RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
			}
			else if(RF2G4_Receive_Data[8] == 1) //��ת�ж�
			{
				R_A_Motor_SetSpeed1(RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
				L_A_Motor_SetSpeed2(-RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
				L_B_Motor_SetSpeed3(-RF2G4_Receive_Data[0] + (100 - RF2G4_Receive_Data[1]));
				R_B_Motor_SetSpeed4(RF2G4_Receive_Data[0] - (100 - RF2G4_Receive_Data[1]));
			}
			else if(RF2G4_Receive_Data[3] == 1) //ɲ���ж�c
			{
				GPIO_ResetBits (GPIOA,GPIO_Pin_3);
				GPIO_ResetBits (GPIOA,GPIO_Pin_4);
				GPIO_ResetBits (GPIOA,GPIO_Pin_8);
				GPIO_ResetBits (GPIOA,GPIO_Pin_9);
				GPIO_ResetBits (GPIOA,GPIO_Pin_10);
				GPIO_ResetBits (GPIOA,GPIO_Pin_11);
				GPIO_ResetBits (GPIOB,GPIO_Pin_10);
				GPIO_ResetBits (GPIOB,GPIO_Pin_11);
			}
			else //ֱ��
			{
				R_A_Motor_SetSpeed1(-RF2G4_Receive_Data[0]);
				L_A_Motor_SetSpeed2(-RF2G4_Receive_Data[0]);
				L_B_Motor_SetSpeed3(-RF2G4_Receive_Data[0]);
				R_B_Motor_SetSpeed4(-RF2G4_Receive_Data[0]);
			}
		}
		else
		{
		Motor_RESET();			
		}
/***************************************************************************************************/
		//��������
		if (RF2G4_Receive_Data[2] == 1)
		{	
			GPIO_SetBits (GPIOC ,GPIO_Pin_14); 
		}

		else
		{
			GPIO_ResetBits (GPIOC ,GPIO_Pin_14); 
		}
		
		//�෽�������
		if (RF2G4_Receive_Data[4] == 1)
		{
			//B4��ת����B4���ر�B5
			GPIO_SetBits (GPIOC,GPIO_Pin_13);
			GPIO_ResetBits (GPIOC,GPIO_Pin_15);
			//�ٶ�
			GPIO_SetBits (GPIOA,GPIO_Pin_12); //�������
			
		}
		else if (RF2G4_Receive_Data[4] == 2)
		{
			//B5��ת����B5���ر�B4
			GPIO_ResetBits (GPIOC,GPIO_Pin_13);
			GPIO_SetBits (GPIOC,GPIO_Pin_15);
			//�ٶ�
			GPIO_SetBits (GPIOA,GPIO_Pin_12);
			
		}
		else 
		{
			GPIO_ResetBits (GPIOC,GPIO_Pin_13);
			GPIO_ResetBits (GPIOC,GPIO_Pin_15);
			GPIO_ResetBits (GPIOA,GPIO_Pin_12);

		}
	
	}	
	else
	{
		OLED_ShowString(2,1,"      ");
		OLED_ShowString(2,1,"ERROR");
	}
		
		OLED_ShowNum(4 ,9 ,RF2G4_Receive_Data[12] ,3);
		OLED_ShowNum(4 ,13 ,RF2G4_Receive_Data[13] ,3);		
		OLED_ShowNum(3 ,1 ,RF2G4_Receive_Data[0] ,4);
		OLED_ShowNum(4 ,1 ,RF2G4_Receive_Data[5] ,1);
		OLED_ShowNum(4 ,3 ,RF2G4_Receive_Data[6] ,1);
		OLED_ShowNum(4 ,5 ,RF2G4_Receive_Data[2] ,1);
		OLED_ShowNum(4 ,7 ,RF2G4_Receive_Data[4] ,1);

		
		
/*********************************/
		//��λ
//		Delay_ms (10);
//		RF2G4_Receive_Data[0] = 0;
//		RF2G4_Receive_Data[1] = 0;
		RF2G4_Receive_Data[12] = 0;
		RF2G4_Receive_Data[13] = 0;
		//RF2G4_Receive_Data[3] = 0; //ɲ���������
/*********************************/	
		
	}
}
